from enum import Enum
from typing import Optional

from sqlmodel import SQLModel, Field


from app.models.user import UserType


class UserLogin(SQLModel):
    """
    What auth router imports.
    If your login endpoint accepts email+password, this is correct.
    """
    email: str
    password: str


class UserRegister(SQLModel):
    username: str
    email: str
    password: str
    full_name: Optional[str] = None


class UserRead(SQLModel):
    id: int
    username: str
    email: str
    full_name: Optional[str] = None
    user_type: UserType  # add this only if you added user_type to the model


class UserUpdate(SQLModel):
    username: Optional[str] = None
    email: Optional[str] = None
    full_name: Optional[str] = None
