from datetime import datetime
from enum import Enum
from typing import Optional

from sqlmodel import SQLModel


from app.models.appointments import ApplicationStatus, AppointmentStatus, RoomStatus


# ---------- Applications ----------

class AppointmentApplicationCreate(SQLModel):
    consultant_user_id: int
    note_from_user: Optional[str] = None


class AppointmentApplicationRead(SQLModel):
    id: int
    user_id: int
    consultant_user_id: int
    note_from_user: Optional[str] = None
    status: ApplicationStatus
    created_at: datetime
    updated_at: datetime


class AppointmentApplicationDecision(SQLModel):
    # consultant accepts/rejects
    status: ApplicationStatus  # accepted / rejected


# ---------- Appointments (Scheduling) ----------

class AppointmentSchedule(SQLModel):
    scheduled_start_at: datetime
    scheduled_end_at: datetime


class AppointmentCreateFromApplication(SQLModel):
    # used when consultant accepts and schedules
    application_id: int
    scheduled_start_at: datetime
    scheduled_end_at: datetime


class AppointmentRead(SQLModel):
    id: int
    application_id: Optional[int] = None
    user_id: int
    consultant_user_id: int
    scheduled_start_at: datetime
    scheduled_end_at: datetime
    status: AppointmentStatus
    created_at: datetime
    updated_at: datetime


class AppointmentStatusUpdate(SQLModel):
    status: AppointmentStatus


# ---------- Session Room ----------

class SessionRoomRead(SQLModel):
    id: int
    appointment_id: int
    status: RoomStatus
    created_at: datetime
    updated_at: datetime


# ---------- Chat ----------

class ChatMessageCreate(SQLModel):
    message: str


class ChatMessageRead(SQLModel):
    id: int
    room_id: int
    sender_user_id: int
    message: str
    sent_at: datetime


# ---------- Notes ----------

class SessionNoteCreate(SQLModel):
    note: str
    is_visible_to_user: bool = False


class SessionNoteUpdate(SQLModel):
    note: Optional[str] = None
    is_visible_to_user: Optional[bool] = None


class SessionNoteRead(SQLModel):
    id: int
    appointment_id: int
    created_by_user_id: int
    note: str
    is_visible_to_user: bool
    created_at: datetime
    updated_at: datetime
