from fastapi import HTTPException
from sqlmodel import Session

from app.models.nutrition_target import NutritionTarget
from app.service.nutrition_target_service import get_current_target, upsert_target_auto


def get_my_target(session: Session, user_id: int) -> NutritionTarget:
    t = get_current_target(session, user_id)
    if not t:
        raise HTTPException(status_code=404, detail="Nutrition target not found. Use PUT to generate one.")
    return t


def put_my_target(session: Session, user_id: int) -> NutritionTarget:
    return upsert_target_auto(session, user_id)
