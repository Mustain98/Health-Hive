from datetime import datetime, timezone
from typing import Optional

from fastapi import HTTPException
from sqlmodel import Session, select

from app.models.user_data import UserData
from app.schemas.user_data import UserDataUpdate

from app.service.auto_goal_adjust import adjust_goal_if_none

from app.controller.nutrition_target_controller import put_my_target

def _get_user_data_for_user(session: Session, user_id: int) -> UserData | None:
    return session.exec(
        select(UserData).where(UserData.user_id == user_id)
    ).first()

def get_current_user_data(session: Session, user_id: int):
    data = _get_user_data_for_user(session, user_id)
    if not data:
        raise HTTPException(status_code=404, detail="User data not found")
    return data


def create_or_update_user_data(session: Session,user_id: int, payload:UserDataUpdate):
    data = _get_user_data_for_user(session, user_id)
    update_data = payload.model_dump(exclude_unset=True)

    if not data:
        data = UserData(user_id=user_id, **update_data)
        session.add(data)
    else:
        for field, value in update_data.items():
            setattr(data, field, value)
        data.updated_at = datetime.now(timezone.utc)
        session.add(data)

    session.commit()
    session.refresh(data)
    
    if data.height_cm is not None and data.weight_kg is not None:
        adjust_goal_if_none(session, user_id, data.weight_kg, data.height_cm)
    put_my_target(session,user_id)
    return data


