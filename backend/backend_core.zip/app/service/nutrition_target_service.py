from datetime import datetime, timezone

from fastapi import HTTPException
from sqlmodel import Session, select

from app.models.nutrition_target import NutritionTarget
from app.models.user_data import UserData
from app.models.user_goal import UserGoal, GoalType
from app.utils.calculate import calculate_bmr_mifflin, calculate_tdee


def _utc_now():
    return datetime.now(timezone.utc)


def _get_goal(session: Session, user_id: int) -> UserGoal:
    goal = session.exec(select(UserGoal).where(UserGoal.user_id == user_id)).first()
    if not goal:
        raise HTTPException(status_code=400, detail="No goal found. Set goal first.")
    return goal


def _get_user_data(session: Session, user_id: int) -> UserData:
    ud = session.exec(
        select(UserData).where(UserData.user_id == user_id).order_by(UserData.created_at.desc())
    ).first()

    if not ud:
        raise HTTPException(status_code=400, detail="No user data found")

    if ud.age is None or ud.gender is None or ud.height_cm is None or ud.weight_kg is None or ud.activity_level is None:
        raise HTTPException(status_code=400, detail="User data incomplete (age/gender/height/weight/activity required)")

    return ud


def _daily_calorie_adjustment(goal: UserGoal) -> int:
    if goal.goal_type == GoalType.maintain:
        return 0

    if goal.duration_days is not None:
        days = goal.duration_days
    elif goal.start_date and goal.end_date:
        days = (goal.end_date - goal.start_date).days + 1
    else:
        raise HTTPException(status_code=400, detail="Goal timeframe missing")

    if days <= 0:
        raise HTTPException(status_code=400, detail="Invalid goal timeframe")

    if goal.target_delta_kg is None:
        raise HTTPException(status_code=400, detail="target_delta_kg missing for lose/gain goal")

    total_kcal = int(round(goal.target_delta_kg * 7700))
    per_day = int(round(total_kcal / days))
    return -per_day if goal.goal_type == GoalType.lose else per_day


def _macro_plan(calories_kcal: int, weight_kg: float) -> tuple[float, float, float]:
    protein_g = 1.8 * weight_kg
    fat_g = 0.8 * weight_kg

    protein_kcal = protein_g * 4
    fat_kcal = fat_g * 9
    remaining = max(calories_kcal - (protein_kcal + fat_kcal), 0)
    carbs_g = remaining / 4

    return round(protein_g, 1), round(carbs_g, 1), round(fat_g, 1)


def get_current_target(session: Session, user_id: int) -> NutritionTarget | None:
    return session.exec(select(NutritionTarget).where(NutritionTarget.user_id == user_id)).first()


def upsert_target_auto(session: Session, user_id: int) -> NutritionTarget:
    goal = _get_goal(session, user_id)
    ud = _get_user_data(session, user_id)

    gender_str = ud.gender.value
    activity_str = ud.activity_level.value

    bmr = calculate_bmr_mifflin(ud.age, gender_str, ud.height_cm, ud.weight_kg)
    tdee = calculate_tdee(ud.age, gender_str, ud.height_cm, ud.weight_kg, activity_str)

    target_cal = int(round(tdee + _daily_calorie_adjustment(goal)))
    protein_g, carbs_g, fat_g = _macro_plan(target_cal, ud.weight_kg)

    existing = get_current_target(session, user_id)

    if not existing:
        nt = NutritionTarget(
            user_id=user_id,
            calories_kcal=target_cal,
            protein_g=protein_g,
            carbs_g=carbs_g,
            fat_g=fat_g,
            created_at=_utc_now(),
            updated_at=_utc_now(),
        )
        session.add(nt)
        session.commit()
        session.refresh(nt)
        return nt

    # update existing (one per user)
    existing.calories_kcal = target_cal
    existing.protein_g = protein_g
    existing.carbs_g = carbs_g
    existing.fat_g = fat_g
    existing.updated_at = _utc_now()

    session.add(existing)
    session.commit()
    session.refresh(existing)
    return existing
